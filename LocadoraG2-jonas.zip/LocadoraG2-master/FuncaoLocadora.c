char menu();

void cadastrar_cliente();


