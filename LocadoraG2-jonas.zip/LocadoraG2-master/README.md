# LocadoraG2

Locadora de filmes

Utilizar structures

Colocar no gitHub

Trabalho em grupo

Salvar os registros em arquivos texto

Limpar a tela toda vez que uma opcao do menu for acessada

Separar os arquivos por pastas

Separar as funções em arquivos

Tirar print das telas para entregar


Banco

Clientes

nome / cpf / telefone / endereco

Filmes

codigo / nome / ano
	
Alugueis

	cliente id / filme id / data do aluguel / data da entrega / valor da multa diaria / valor pago
	
	// calcular os dias de atraso
	


**Extra -> Inserir uma linha de mapeamento, para o usuario saber para onde voltar 
