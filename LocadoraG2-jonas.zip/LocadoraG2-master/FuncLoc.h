char menu();

void cadastrar_filme();

void listar_filmes();




